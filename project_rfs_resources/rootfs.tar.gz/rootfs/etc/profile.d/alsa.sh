ALSA_CONFIG_PATH=/alsa-lib/share/alsa/alsa.conf
export ALSA_CONFIG_PATH
LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/alsa-lib/lib:/alsa-lib/lib/alsa-lib:/alsa-lib/lib/alsa-lib/smixer
export LD_LIBRARY_PATH
